<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpress' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'JiXSLsQKL@d qz{Mis#][I}I?{U!i-9BBiqL+ESRz1oCr4cS<$/Wj8HuDOHa#c4H' );
define( 'SECURE_AUTH_KEY',  'S+9e3A(5+PvG0>B8:y5C68Rt4!2IFzO9l=bA1-=pQbf:0qmrK4QlH20ZXEqsq@oQ' );
define( 'LOGGED_IN_KEY',    ' !ujh=b{86At=G_$jsYmc$J/lE&9dJKR$DURFdy9zZW4- 7)c-p94oe!<}I57OVe' );
define( 'NONCE_KEY',        '_)xI{BJ`v;,u}fSnjodwt~9e+C&0)f {sR^!*snrfmg8O{UZ<I)o,v,Iey!M g;s' );
define( 'AUTH_SALT',        'qmZyT$_k,vy^x2j](+,Y}7oW7h_zzza9i~YRQ-y&;TvI>s/ChX$)e;mE$f^y>X@2' );
define( 'SECURE_AUTH_SALT', '36yDLmMg,sze7[n63m>FBy1QQ((~NW?cC:kbtwKl@-2$jf &7(>]laNQFod@u,W&' );
define( 'LOGGED_IN_SALT',   'Fx-{A09! $>4U<:*Ui |YPk2K2{nT.6j6Ou|7ze4b:b`4u;B?6;O7jShB#Z{LqRQ' );
define( 'NONCE_SALT',       'uZ?Y5QZtZ]JO0T+=cRNMM?A<nI)BJ:)t2sHdgt[e{}g~<t.30dtru(*cSqTm*VS[' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
