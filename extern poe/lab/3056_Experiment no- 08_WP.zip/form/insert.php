<!DOCTYPE html>
<html>

<head>
	<title>Insert Page</title>
</head>

<body>
	<center>
		<?php

		// servername => localhost
		// username => root
		// password => empty
		// database name => staff
		$conn = mysqli_connect("localhost", "root", "", "Student_information");
		
		// Check connection
		if($conn === false){
			die("ERROR: Could not connect. "
				. mysqli_connect_error());
		}
		
		// Taking all 5 values from the form data(input)
		$NAME = $_REQUEST['NAME'];
		$PASSWORD = $_REQUEST['PASSWORD'];
		$MOB_NO = $_REQUEST['MOB_NO'];
		$BIRTH_DATE = $_REQUEST['BIRTH_DATE'];
		$ADHAR_ID = $_REQUEST['ADHAR_ID'];
		$EMAIL = $_REQUEST['EMAIL'];
		
		// Performing insert query execution
		// here our table name is college
		$sql = "INSERT INTO Student_information VALUES ('$NAME',
			'$PASSWORD',$MOB_NO','$BIRTH_DATE','$ADHAR_ID','$EMAIL')";
		
		if(mysqli_query($conn, $sql)){
			echo "<h3>data stored in a database successfully."
				. " Please browse your localhost php my admin"
				. " to view the updated data</h3>";

			echo nl2br("\n$NAME\n \n$PASSWORD\n $MOB_NO\n "
				. "$BIRTH_DATE\n $ADHAR_ID\n $EMAIL");
		} else{
			echo "ERROR: Hush! Sorry $sql. "
				. mysqli_error($conn);
		}
		
		// Close connection
		mysqli_close($conn);
		?>
	</center>
</body>

</html>
