<!DOCTYPE html>
<html>
<body>

<h2 style="text-align: center;">Student Registration form</h2>
<center>
<form action="insert.php" method="post">
			
<p>
			<label for="NAME">NAME:</label>
			<input type="text" name="NAME" id="NAME">
			</p>			
<p>
<p>
			<label for="PASSWORD">PASSWPORD:</label>
			<input type="text" name="PASSWORD" id="PASSWORD">
			</p>			
<p>
			<label for="MOB_NO">MOB_NO:</label>
			<input type="text" name="MOB_NO" id="MOB_NO">
			</p>			
<p>
			<label for="BIRTH_DATE">BIRTH_DATE:</label>
			<input type="date" name="BIRTH_DATE" id="BIRTH_DATE">
			</p>			
<p>
			<label for="ADHAR_ID">ADHAR_ID:</label>
			<input type="text" name="ADHAR_ID" id="ADHAR_ID">
			</p>			
<p>
			<label for="EMAIL">EMAIL:</label>
			<input type="email" name="EMAIL" id="EMAIL">
			</p>

			<input type="submit" value="Submit">
		</form> 
<?php


		// servername => localhost
		// username => root
		// password => empty
		// database name => staff
		$conn = mysqli_connect("localhost", "root", "", "student_information");
		// Check connection
		if($conn === false){
			die("ERROR: Could not connect.".mysqli_connect_error());
		}
		// Taking all 5 values from the form data(input)
		$NAME = $_REQUEST['NAME'];
    	$PASSWORD = $_REQUEST['PASSWORD'];
		$MOB_NO = $_REQUEST['MOB_NO'];
		$BIRTH_DATE = $_REQUEST['BIRTH_DATE'];
		$ADHAR_ID = $_REQUEST['ADHAR_ID'];
		$EMAIL = $_REQUEST['EMAIL'];
		
		// Performing insert query execution
		// here our table name is college
		$sql = "INSERT INTO Student_information VALUES ('$NAME','$PASSWORD','$MOB_NO','$BIRTH_DATE','$ADHAR_ID','$EMAIL')";
		
		if(mysqli_query($conn, $sql)){
			echo "<h3>data stored in a database successfully."
				. " Please browse your localhost php my admin"
				. " to view the updated data</h3>";

			echo nl2br("\n$NAME\n \n$PASSWORD\n $MOB_NO\n $BIRTH_DATE\n $ADHAR_ID\n $EMAIL");
		} else{
			echo "ERROR: Hush! Sorry $sql. "
				. mysqli_error($conn);
		}
		
		// Close connection
		mysqli_close($conn);
		?>
    </center>
</body>
</html>