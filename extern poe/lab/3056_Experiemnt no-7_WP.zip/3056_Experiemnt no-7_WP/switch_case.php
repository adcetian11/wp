<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <h1>switch - case example in php</h1>
    <?php
    $day=5;
    switch($day):
        case "1":
        {
         echo"its Monday";
         break;
        }
        case "2":
        {
         echo"its Monday";
         break;
        }
        case "3":
        {
         echo"its Wednesday";
        }  
        case "4":
        {
         echo"its Thursday";   
        }
        case "5":
        {
         echo"its Friday";
        }
        case "6":
        {
         echo"its Saturday";  
        }
        case "7":
        {
         echo"its Sunday";
        }
        default:
        {
         echo("Invalid input!!");
        }
    ?>
</body>

</html>