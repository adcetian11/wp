<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    $marks=46;
    if($marks>=60)
    {
        $grade="1 st grade";
    }
    elseif($marks>=40)
    {
        $grade="2 nd grade";
    }
    elseif($mark>=33)
    {
        $grade="3 rd grade";
    }
    else
    {
        $grade="failed";
    }
    echo"<br>marks=",$marks,"<br>grade is:",$grade; 
    ?>
</body>
</html>