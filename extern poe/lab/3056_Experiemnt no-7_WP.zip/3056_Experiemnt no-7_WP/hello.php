<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<h1>this is my first php code!</h1>
<?php
echo"Hello World";
//this is comment in php
# this is comment
$var1=15;
$var2=17;
echo"<br>addition is:",$var1+$var2;
?>
</body>
</html>
