<?php

$con = mysqli_connect("localhost","root","","busregistration");


if(!$con)
{
    die("Connection Failed: ".mysqli_connect_error());

}


?>