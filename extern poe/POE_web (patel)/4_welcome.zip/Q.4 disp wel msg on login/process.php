<?php
include_once 'database.php';
if(isset($_POST['log']))
{	 
	 $Name = $_POST['name'];
	 $Address = $_POST['address'];
	 $Email = $_POST['email'];
	 $Password = $_POST['Pass'];
	 $sql = "INSERT INTO mm (Name,Address,Email,Password)
	 VALUES ('$Name','$Address','$Email','$Password')";
	 if (mysqli_query($conn, $sql)) {
		echo "New record created successfully !";
	 } else {
		echo "Error: " . $sql . "
" . mysqli_error($conn);
	 }
	 mysqli_close($conn);
}
?>