<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration For Bank</title>
    <style>
 body  
{  
    margin: 20;  
    padding: 0;  
    background-color:#6abadeba;  
    font-family: 'Arial';  
}  
.res{
        width: 382px;  
        overflow: hidden;  
        margin: auto;  
        margin: 20 0 0 450px;  
        padding: 80px;  
        background: paleturquoise;  
        border-radius: 15px ;  
}
h1{  
    text-align: center;  
    color: #277582;  
    padding: 20px;  
}  
label{  
    color: black;  
    font-size: 17px;  
}  
#name{  
    width: 300px;  
    height: 30px;  
    border: none;  
    border-radius: 3px;  
    padding-left: 8px;  
}  
#address{  
    width: 300px;  
    height: 30px;  
    border: none;  
    border-radius: 3px;  
    padding-left: 8px;  
}  
#email{  
    width: 300px;  
    height: 30px;  
    border: none;  
    border-radius: 3px;  
    padding-left: 8px;  
}  
#Pass{  
    width: 300px;  
    height: 30px;  
    border: none;  
    border-radius: 3px;  
    padding-left: 8px;  
      
}  
#log{  
    width: 350px;  
    height: 40px;  
    border: none;  
    border-radius: 17px;  
    background-color: black;
    font-size: 20px;
    color: #fff;  
  
  
}  
span{  
    color: black;  
    font-size: 17px;  
}  

    
</style>
</head>

<body>
        <div class="res">
                <form action="process.php"method="POST">
                    <h1>Registration</h1>    
                            <label><b>Name</b></label>    <br>
                            <input type="text" name="name" id="name" placeholder="Enter your name..."><br><br>
                            <label><b>Address</b></label>   <br> 
                            <input type="text" name="address" id="address" placeholder="Enter your address"><br><br>
                            <label><b>Email</b></label>   <br> 
                            <input type="email" name="email" id="email" placeholder="Enter your email..."><br><br>     
                            <label><b>Password</b></label>    
                            <input type="Password" name="Pass" id="Pass" placeholder="Enter your password..."><br><br>    
                            <input type="submit" name="log" id="log" value="Register"><br><br>    
                            <input type="checkbox" id="check">    
                            <span>Remember me</span><br><br>   
                    <p>You have already registered? <a href="4_login.php">Login</a></p>
                </form>
            </div>
        </div>
</body>
</html>
