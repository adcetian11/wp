<?php

require 'database.php';
if(!empty($_SESSION["id"])){
  header("Location: indexr.php");
}
if(isset($_POST["log"])){
  $name = $_POST["Uname"];
  $password = $_POST["Pass"];
  $result = mysqli_query($conn, "SELECT * FROM mm WHERE Name = '$name'");
  $row = mysqli_fetch_assoc($result);
  if(mysqli_num_rows($result) > 0){
    if($password == $row['Password']){
      $_SESSION["login"] = true;
      $_SESSION["id"] = $row["id"];
      header("Location: indexr.php");
    
    }
    else{
      echo
      "<script> alert('Wrong Password'); </script>";
    }
  }
  else{
    echo
    "<script> alert('User Not Registered'); </script>";
  }
}
?>



<!DOCTYPE html>    
<html>    
<head>    
    <title>Login Form For Bank</title>    
    <link rel="stylesheet" type="text/css" href="css/style.css">   
    <style>
        body  
{  
    margin: 0;  
    padding: 0;  
    background-color:#6abadeba;  
    font-family: 'Arial';  
}  
.login{  
        width: 382px;  
        overflow: hidden;  
        margin: auto;  
        margin: 20 0 0 450px;  
        padding: 80px;  
        background: paleturquoise; 
        border-radius: 15px ;  
          
}  
h1{  
    text-align: center;  
    color: #277582;  
    padding: 20px;  
}  
label{  
    color:black  
    font-size: 17px;  
}  
#Uname{  
    width: 300px;  
    height: 30px;  
    border: none;  
    border-radius: 3px;  
    padding-left: 8px;  
}  
#Pass{  
    width: 300px;  
    height: 30px;  
    border: none;  
    border-radius: 3px;  
    padding-left: 8px;  
      
}  
#log{  
    width: 350px;  
    height: 40px;  
    border: none;  
    border-radius: 17px;  
    background-color: black;
    font-size: 20px;
    color: #fff;  
  
  
}  
#logi{  
    width: 350px;  
    height: 40px;  
    border: none;  
    border-radius: 17px;  
    background-color: black;
    font-size: 20px;
    color: #fff;  
  
  
}  
span{  
    color: black;  
    font-size: 17px;  
}  
 
    </style> 
</head>    
<body>    
    <h1>Login Page</h1><br>    
    <div class="login">    
    <form id="login" method="POST">    
        <label><b>User Name     
        </b>    
        </label>    
        <input type="text" name="Uname" id="Uname" placeholder="Username">    
        <br><br>    
        <label><b>Password     
        </b>    
        </label>  <br>  
        <input type="Password" name="Pass" id="Pass" placeholder="Password">    
        <br><br>    
        <input type="submit" name="log" id="log" value="Log In Here">       
        <br><br>       
        <span>Remember me</span>    
        <br><br>     
    </form> 
    </form>     
</div>    
</body>    
</html>     


